-- FamilyStore: make the first registered account the store administrator
-- First create/sign up this email in Supabase Authentication, then run this once.
update public.profiles p
set role = 'admin',
    trader_status = 'approved',
    updated_at = now()
from auth.users u
where p.id = u.id
  and lower(u.email) = lower('aabw3171@gmail.com');

-- Verify the administrator assignment:
select u.email, p.role, p.trader_status
from auth.users u
join public.profiles p on p.id = u.id
where lower(u.email) = lower('aabw3171@gmail.com');
