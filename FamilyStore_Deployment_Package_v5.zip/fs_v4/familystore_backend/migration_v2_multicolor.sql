-- FamilyStore migration v2: multiple colors, one image per color, size stock per color.
-- Run AFTER schema.sql in Supabase SQL Editor.

create table if not exists public.product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  color_name text not null,
  image_url text,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  unique(product_id, color_name)
);

alter table public.product_sizes
  add column if not exists variant_id uuid references public.product_variants(id) on delete cascade;

-- Preserve any sizes already entered by creating a default variant per product.
insert into public.product_variants(product_id, color_name, image_url, sort_order)
select p.id, 'اللون الأساسي', p.image_url, 0
from public.products p
where exists (select 1 from public.product_sizes s where s.product_id = p.id)
  and not exists (select 1 from public.product_variants v where v.product_id = p.id);

update public.product_sizes s
set variant_id = v.id
from public.product_variants v
where v.product_id = s.product_id
  and s.variant_id is null;

-- New sizes must belong to a specific color variant.
alter table public.product_sizes alter column variant_id set not null;
alter table public.product_sizes drop constraint if exists product_sizes_product_id_size_label_key;
alter table public.product_sizes
  add constraint product_sizes_variant_id_size_label_key unique(variant_id, size_label);

alter table public.order_items add column if not exists color_name text not null default '';

alter table public.product_variants enable row level security;
drop policy if exists "read variants for active products" on public.product_variants;
drop policy if exists "admin manage variants" on public.product_variants;
create policy "read variants for active products" on public.product_variants
  for select to anon, authenticated
  using (exists(select 1 from public.products p where p.id = product_id and (p.is_active or public.is_admin())));
create policy "admin manage variants" on public.product_variants
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Refresh size read policy to follow the variant's product.
drop policy if exists "read sizes for active products" on public.product_sizes;
create policy "read sizes for active products" on public.product_sizes
  for select to anon, authenticated
  using (exists(
    select 1 from public.product_variants v
    join public.products p on p.id = v.product_id
    where v.id = variant_id and (p.is_active or public.is_admin())
  ));

-- Public image reads; only admins may upload/change/delete images.
-- Create the public bucket in Storage first, or run the insert below if desired.
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do update set public = true;

drop policy if exists "Public read FamilyStore product images" on storage.objects;
drop policy if exists "Admins upload FamilyStore product images" on storage.objects;
drop policy if exists "Admins update FamilyStore product images" on storage.objects;
drop policy if exists "Admins delete FamilyStore product images" on storage.objects;
create policy "Public read FamilyStore product images" on storage.objects
  for select to anon, authenticated
  using (bucket_id = 'product-images');
create policy "Admins upload FamilyStore product images" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'product-images' and public.is_admin());
create policy "Admins update FamilyStore product images" on storage.objects
  for update to authenticated
  using (bucket_id = 'product-images' and public.is_admin())
  with check (bucket_id = 'product-images' and public.is_admin());
create policy "Admins delete FamilyStore product images" on storage.objects
  for delete to authenticated
  using (bucket_id = 'product-images' and public.is_admin());

-- Verification queries
select count(*) as product_variants_count from public.product_variants;
select count(*) as sizes_without_variant from public.product_sizes where variant_id is null;
