-- FamilyStore database schema for Supabase (PostgreSQL)
-- Run in Supabase Dashboard > SQL Editor. Review before production.
create extension if not exists pgcrypto;

create type public.account_role as enum ('customer','trader','admin');
create type public.account_status as enum ('pending','approved','rejected');
create type public.order_status as enum ('new','confirmed','preparing','shipped','delivered','cancelled');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text not null default '',
  role public.account_role not null default 'customer',
  trader_status public.account_status not null default 'pending',
  business_name text,
  tax_number text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null default '',
  category text not null check (category in ('Baby','Kids','Junior')),
  gender text not null default 'مشترك',
  retail_price numeric(10,2) not null check (retail_price >= 0),
  wholesale_price numeric(10,2) not null check (wholesale_price >= 0),
  wholesale_min integer not null default 6 check (wholesale_min > 0),
  image_url text,
  featured boolean not null default false,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.product_sizes (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  size_label text not null,
  stock integer not null default 0 check (stock >= 0),
  unique(product_id, size_label)
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  user_id uuid references auth.users(id) on delete set null,
  customer_name text not null,
  phone text not null,
  governorate text not null,
  area text not null,
  address text not null,
  notes text not null default '',
  sales_type text not null check (sales_type in ('retail','wholesale')),
  subtotal numeric(10,2) not null check (subtotal >= 0),
  shipping_cost numeric(10,2) not null default 0 check (shipping_cost >= 0),
  total numeric(10,2) not null check (total >= 0),
  payment_method text not null default 'cash_on_delivery',
  status public.order_status not null default 'new',
  created_at timestamptz not null default now()
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  size_label text not null,
  quantity integer not null check (quantity > 0),
  unit_price numeric(10,2) not null check (unit_price >= 0),
  sales_type text not null check (sales_type in ('retail','wholesale'))
);

create table public.store_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

-- New users always start as customers. A user cannot grant themselves trader/admin status.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, full_name, phone)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), coalesce(new.raw_user_meta_data->>'phone',''));
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

create or replace function public.is_approved_trader()
returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'trader' and trader_status = 'approved');
$$;

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.product_sizes enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.store_settings enable row level security;

-- Profiles: each user can see/update their own basic profile; only admins can manage roles/status.
create policy "profile read own or admin" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_admin());
create policy "profile update own basic fields" on public.profiles for update to authenticated
using (id = auth.uid()) with check (id = auth.uid() and role = (select p.role from public.profiles p where p.id = auth.uid()) and trader_status = (select p.trader_status from public.profiles p where p.id = auth.uid()));
create policy "admin manage profiles" on public.profiles for all to authenticated
using (public.is_admin()) with check (public.is_admin());

-- Public can browse active products and stock. Writes are admin-only.
create policy "read active products" on public.products for select to anon, authenticated using (is_active or public.is_admin());
create policy "admin manage products" on public.products for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "read sizes for active products" on public.product_sizes for select to anon, authenticated
using (exists(select 1 from public.products p where p.id = product_id and (p.is_active or public.is_admin())));
create policy "admin manage sizes" on public.product_sizes for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Customers can create COD orders. Customers can only read their own orders; admins can manage all.
create policy "customer create order" on public.orders for insert to anon, authenticated
with check (status = 'new' and payment_method = 'cash_on_delivery' and (user_id is null or user_id = auth.uid()));
create policy "read own orders or admin" on public.orders for select to authenticated
using (user_id = auth.uid() or public.is_admin());
create policy "admin update orders" on public.orders for update to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "create order items" on public.order_items for insert to anon, authenticated
with check (exists(select 1 from public.orders o where o.id = order_id and o.status = 'new' and (o.user_id is null or o.user_id = auth.uid())));
create policy "read own order items or admin" on public.order_items for select to authenticated
using (exists(select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_admin())));
create policy "admin manage order items" on public.order_items for all to authenticated
using (public.is_admin()) with check (public.is_admin());

create policy "read public settings" on public.store_settings for select to anon, authenticated using (key in ('shipping','public_contact'));
create policy "admin manage settings" on public.store_settings for all to authenticated using (public.is_admin()) with check (public.is_admin());

insert into public.store_settings(key,value) values
('public_contact','{"whatsapp":""}'::jsonb),
('shipping','{"القاهرة":55,"الجيزة":55,"الإسكندرية":65}'::jsonb)
on conflict (key) do nothing;

-- Storage bucket for product images. Create bucket "product-images" as PUBLIC in Storage UI.
-- Add storage policies separately as described in SETUP.md.
